package com.example.chatapp

import android.app.Activity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.UUID
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var phone: EditText
    private lateinit var otp: EditText
    private lateinit var name: EditText
    private lateinit var device: TextView
    private lateinit var action: Button
    private lateinit var status: TextView
    private val auth by lazy { FirebaseAuth.getInstance() }
    private var verificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var stage = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        phone = findViewById(R.id.phone); otp = findViewById(R.id.otp); name = findViewById(R.id.name)
        device = findViewById(R.id.device); action = findViewById(R.id.action); status = findViewById(R.id.status)
        otp.visibility = View.GONE; name.visibility = View.GONE; device.visibility = View.GONE
        action.setOnClickListener { next() }
        if (auth.currentUser != null) showAuthenticatedState() else status.text = "Enter your mobile number"
    }

    private fun next() {
        when (stage) {
            0 -> sendOtp()
            1 -> verifyOtp()
            2 -> createProfile()
            else -> status.text = "Home opened — session active"
        }
    }

    private fun sendOtp() {
        val number = phone.text.toString().trim()
        if (!number.startsWith("+") || number.length < 10) { status.text = "Use full number with country code, e.g. +923001234567"; return }
        status.text = "Sending SMS OTP…"; action.isEnabled = false
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(number)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(callbacks)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
            auth.signInWithCredential(credential).addOnCompleteListener { if (it.isSuccessful) afterVerification() else fail(it.exception) }
        }
        override fun onVerificationFailed(e: FirebaseException) { action.isEnabled = true; status.text = "OTP failed: ${e.localizedMessage}" }
        override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
            verificationId = id; resendToken = token; stage = 1
            phone.isEnabled = false; otp.visibility = View.VISIBLE; action.isEnabled = true; action.text = "Verify OTP"
            status.text = "SMS sent. Enter the 6-digit code."
        }
    }

    private fun verifyOtp() {
        val code = otp.text.toString().trim()
        val id = verificationId
        if (id == null || code.length != 6) { status.text = "Enter the 6-digit OTP"; return }
        action.isEnabled = false
        auth.signInWithCredential(PhoneAuthProvider.getCredential(id, code)).addOnCompleteListener {
            action.isEnabled = true
            if (it.isSuccessful) afterVerification() else fail(it.exception)
        }
    }

    private fun afterVerification() {
        stage = 2; otp.visibility = View.GONE; name.visibility = View.VISIBLE
        action.text = "Create Account"; status.text = "Phone verified successfully"
    }

    private fun createProfile() {
        val n = name.text.toString().trim()
        if (n.isEmpty()) { status.text = "Enter your name"; return }
        val id = getDeviceId()
        device.visibility = View.VISIBLE
        device.text = "Device ID: $id\nRegistered to: $n"
        getSharedPreferences("session", MODE_PRIVATE).edit().putBoolean("profile_created", true).apply()
        stage = 3; action.text = "Open Home"; status.text = "Account and device session ready"
    }

    private fun showAuthenticatedState() {
        stage = 3; phone.visibility = View.GONE; otp.visibility = View.GONE; name.visibility = View.GONE
        device.visibility = View.VISIBLE; device.text = "Device ID: ${getDeviceId()}\nFirebase session active"
        action.text = "Open Home"; status.text = "Already signed in"
    }

    private fun getDeviceId(): String {
        val prefs = getSharedPreferences("device", MODE_PRIVATE)
        prefs.getString("device_id", null)?.let { return it }
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: UUID.randomUUID().toString()
        val id = UUID.nameUUIDFromBytes((androidId + packageName).toByteArray()).toString()
        prefs.edit().putString("device_id", id).apply()
        return id
    }

    private fun fail(e: Exception?) { status.text = e?.localizedMessage ?: "Verification failed" }
}
