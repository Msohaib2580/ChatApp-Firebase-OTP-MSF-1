# Backend API contract

Production flow:
1. POST /auth/send-otp {phone_number,country_code}
2. POST /auth/verify-otp {phone_number,otp,device_id,device_name,platform,app_version}
3. POST /auth/refresh {refresh_token}
4. POST /devices/register {device_id,device_name,platform,app_version,push_token}
5. GET /devices
6. POST /devices/{device_id}/revoke
7. POST /auth/logout

Database tables: users, otp_sessions, devices, sessions.

Security: hash OTPs, expire OTPs after ~5 minutes, rate-limit send/verify attempts, use TLS, short-lived access tokens + refresh tokens, revoke sessions on logout, and do not collect IMEI.

The Android sample uses demo OTP 123456 locally. Replace it with a real SMS provider and server-side verification before production.
