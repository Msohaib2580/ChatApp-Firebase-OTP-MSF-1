# ChatApp Login + OTP + Device ID Starter

Android Kotlin starter implementing:
- Mobile number screen
- Demo OTP verification (123456)
- Profile name
- App-generated stable Device ID (no IMEI)
- Basic home/auth completion state

Open this folder in Android Studio and build the app. For production, connect the backend API in backend/README.md and replace demo OTP with server-side SMS verification.
