# Firebase Phone Auth setup

1. Create a Firebase project.
2. Add an Android app with package name `com.example.chatapp`.
3. Download `google-services.json` and place it in `login_otp_device_app/app/`.
4. In Firebase Console, enable **Authentication → Sign-in method → Phone**.
5. Configure the required SMS/region settings and add your SHA-1/SHA-256 fingerprints for the release/debug builds.
6. Open the project in Android Studio and sync Gradle.
7. Run the app on a real Android device. Enter a full number such as `+923001234567`.

The app uses Firebase Phone Authentication for real SMS OTP. It does not collect IMEI. The device ID is an app-generated UUID derived from the Android app installation/device identifier and stored locally for the app session.

For production, add Firestore/Realtime Database security rules and a server-side device registry. Never put server secrets or service-account keys in the Android APK.
