# ChatApp — Firebase Phone Auth + OTP + Device ID

Production-style Android starter. Real SMS OTP is handled by Firebase Phone Authentication; no demo OTP is hard-coded.

## Included
- Phone number login
- Firebase SMS OTP verification
- Firebase auth session restoration
- App-generated Device ID (no IMEI)
- Profile step
- Existing image/audio assets

## Required before build
- Add your own `app/google-services.json` from Firebase Console.
- Enable Phone Authentication in Firebase.
- Configure SHA-1/SHA-256 fingerprints.
- Review SMS region/quota settings.

Do not commit `google-services.json` if your repository policy requires it to remain private, and never include Firebase service-account private keys in the mobile app.
